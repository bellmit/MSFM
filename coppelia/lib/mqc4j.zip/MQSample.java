// ===========================================================================
//
// Licensed Materials - Property of IBM
//
// 5639-C34
//
// (c) Copyright IBM Corp. 1997
//
// ===========================================================================
// MQSeries Client for Java sample applet
//
// This sample runs as an applet using the appletviewer and HTML file,
// using the command :-
//            appletviewer MQSample.html
// Output is to the command line, NOT the applet viewer window.
//
// Note. If you receive MQ error 2 reason 2059 and you are sure your MQ and TCPIP
// setup is correct,
// you should click on the "Applet" selection in the Applet viewer window
// select properties, and change "Network access" to unrestricted.

import com.ibm.mq.*;            // Include the MQ package

public class MQSample extends java.applet.Applet
{

  private String hostname = "your_hostname";           // define the name of your host to connect to
  private String channel  = "server_channel";          // define name of channel for client to use
                                                       // Note. assumes MQ Server is listening on
                                                       // the default TCP/IP port of 1414
  private String qManager = "your_Q_manager";          // define name of queue manager object to
                                                       // connect to.

  private MQQueueManager qMgr;                         // define a queue manager object

  // When the class is called, this initialisation is done first.

  public void init()
  {
     // Set up MQ environment
     MQEnvironment.hostname = hostname;              // Could have put the hostname & channel
     MQEnvironment.channel  = channel;               // string directly here!

  } // end of init


  public void start()
  {

    try {
      // Create a connection to the queue manager
      qMgr = new MQQueueManager(qManager);

      // Set up the options on the queue we wish to open...
      // Note. All MQ Options are prefixed with MQC in Java.

      int openOptions = MQC.MQOO_INPUT_AS_Q_DEF |
                        MQC.MQOO_OUTPUT ;

      // Note. MQOO_INQUIRE & MQOO_SET are always included by default.

      // Now specify the queue that we wish to open, and the open options...

      MQQueue system_default_local_queue =
              qMgr.accessQueue("SYSTEM.DEFAULT.LOCAL.QUEUE",
                               openOptions,
                               null,           // default q manager
                               null,           // no dynamic q name
                               null);          // no alternate user id


      // Define a simple MQ message, and initialise it in UTF format..

      MQMessage hello_world = new MQMessage();
      hello_world.writeUTF("Hello World!");

      // specify the message options...

      MQPutMessageOptions pmo = new MQPutMessageOptions();  // accept the defaults, same
                                                            // as MQPMO_DEFAULT constant

      // put the message on the queue

      system_default_local_queue.put(hello_world,pmo);

      // get the message back again...
      // First define a MQ message buffer to receive the message into..

      MQMessage retrievedMessage = new MQMessage();
      retrievedMessage.messageId = hello_world.messageId;

      // Set the get message options..

      MQGetMessageOptions gmo = new MQGetMessageOptions();  // accept the defaults
                                                            // same as MQGMO_DEFAULT

      // get the message off the queue..

      system_default_local_queue.get(retrievedMessage,
                                     gmo,
                                     100);              // max message size

      // And prove we have the message by displaying the UTF message text

      String msgText = retrievedMessage.readUTF();
      System.out.println("The message is: " + msgText);

      // Close the queue

      system_default_local_queue.close();

      // Disconnect from the queue manager

      qMgr.disconnect();

    }

    // If an error has occured in the above, try to identify what went wrong.
    // Was it an MQ error?

    catch (MQException ex)
    {
      System.out.println("An MQ error occurred : Completion code " +
                         ex.completionCode +
                         " Reason code " + ex.reasonCode);
    }
    // Was it a Java buffer space error?
    catch (java.io.IOException ex)
    {
      System.out.println("An error occurred whilst writing to the message buffer: " +
                         ex);
    }

  } // end of start

} // end of sample

